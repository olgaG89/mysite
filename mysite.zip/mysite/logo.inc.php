<div class="logo"> 
<img src="logoImg.png" alt="php">
</div>           