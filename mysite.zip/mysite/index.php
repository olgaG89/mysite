

<?php
 $p = "Приветствую Вас на моей страничке!"
 ?>

 <?php
  $name = 'Ольга';
  $surname = 'Грабко';
  $city = "Москва";
  $age = 33;
  ?>


<?php
include 'main.php';
?>